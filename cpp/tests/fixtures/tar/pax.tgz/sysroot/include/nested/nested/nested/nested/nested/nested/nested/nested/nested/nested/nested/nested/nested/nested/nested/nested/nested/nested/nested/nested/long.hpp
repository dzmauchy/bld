namespace test { const char* label = "µ"; }
